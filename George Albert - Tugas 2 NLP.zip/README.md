George Albert - 1406569781

Kode ini diadaptasi dari kode Daniel Shiffman (https://github.com/CodingTrain/), yang menggunakan p5.js untuk menyeleksi kata. License aslinya masih dapat dilihat di file-file .js.